import { Component } from '@angular/core';
// import {TranslatePipe, TranslateDirective} from "@ngx-translate/core";

@Component({
  selector: 'app-work-together',
  standalone: true,
  imports: [
    // TranslatePipe, TranslateDirective
  ],
  templateUrl: './work-together.component.html',
  styleUrl: './work-together.component.sass'
})
export class WorkTogetherComponent {

}
